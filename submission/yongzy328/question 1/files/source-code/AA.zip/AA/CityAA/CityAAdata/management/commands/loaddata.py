#from typing import Self
from django.core.management.base import BaseCommand
import json
from CityAAdata.models import Inspection
from datetime import datetime

class Command(BaseCommand): 
    help = 'Load JSON data into Django models'

    def add_arguments(self, parser):
        parser.add_argument('json_file', type=str, help='Path to the JSON file')

    def handle(self, *args, **options):
        json_file = options['json_file']
        with open(json_file, 'r') as file:
            data = json.load(file)

            for item in data:
                # Convert the 'date' field to a datetime object
                date = datetime.strptime(item['date'], "%b %d %Y").date()

                address = item['address']

                zip_code = address.get('zip', None)

                inspection = Inspection(
                    id=item['id'],
                    certificate_number=item['certificate_number'],
                    business_name=item['business_name'],
                    date=date,
                    result=item['result'],
                    sector=item['sector'],
                    city=address['city'],
                    zip=int(zip_code) if zip_code else None,
                    street=address['street'],
                    number=address['number']
                )
                inspection.save()

        self.stdout.write(self.style.SUCCESS('Data loaded successfully.'))