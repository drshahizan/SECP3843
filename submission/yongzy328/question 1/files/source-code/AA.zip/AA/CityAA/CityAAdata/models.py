from django.db import models

class Inspection(models.Model):
    id = models.CharField(max_length=100, primary_key=True)
    certificate_number = models.CharField(max_length=50)
    business_name = models.CharField(max_length=255)
    date = models.DateField()
    result = models.CharField(max_length=255)
    sector = models.CharField(max_length=255)
    city = models.CharField(max_length=255, db_column='address.city')
    zip = models.IntegerField(db_column='address.zip')
    street = models.CharField(max_length=255, db_column='address.street')
    number = models.CharField(max_length=10,  db_column='address.number')

    def __str__(self):
        return self.name
       