from django.apps import AppConfig


class Q3AppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Q3_APP'
