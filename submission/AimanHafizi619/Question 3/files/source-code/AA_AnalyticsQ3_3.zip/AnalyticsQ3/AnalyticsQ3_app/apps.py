from django.apps import AppConfig


class Analyticsq3AppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'AnalyticsQ3_app'
