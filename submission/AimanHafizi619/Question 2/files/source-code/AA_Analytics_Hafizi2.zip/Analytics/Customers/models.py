from django.db import models
from django.contrib.postgres.fields import ArrayField

class Customers(models.Model):
    username = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    address = models.CharField(max_length=200)
    birthdate = models.DateField()
    email = models.EmailField()
    accounts = models.ArrayField(models.IntegerField())
    tier_and_details = models.JSONField()
