from django.db import models
from django.contrib.postgres.fields import ArrayField

class Transactions(models.Model):
    account_id = models.IntegerField()
    transaction_count = models.IntegerField()
    bucket_start_date = models.DateField()
    bucket_end_date = models.DateField()
    transactions = models.JSONField()
