from django.apps import AppConfig


class AaAppConfig(AppConfig):
    name = 'aa_app'
